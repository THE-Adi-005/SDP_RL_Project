"""LinUCB (Disjoint) — Contextual bandit with linear payoffs and UCB exploration.

For each arm a, maintains:
  Aₐ = d×d matrix (initialized to identity)
  bₐ = d-dim vector (initialized to zero)

Prediction: θ̂ₐ = Aₐ⁻¹ bₐ  (ridge regression solution)
Selection:  arm = argmax( θ̂ₐᵀx + α * sqrt(xᵀ Aₐ⁻¹ x) )

The second term is the UCB bonus — wider for less-explored (state, arm) pairs.

Reference: Li, L., Chu, W., Langford, J., & Schapire, R. E. (2010).
           "A contextual-bandit approach to personalized news article recommendation."
           Proceedings of the 19th International Conference on World Wide Web (WWW).

Regret bound: O(d * sqrt(T * ln(T)))
"""
import numpy as np


class LinUCB:
    """Disjoint LinUCB — the primary proposed contextual bandit algorithm."""

    def __init__(self, n_actions: int = 4, alpha: float = 1.0, feature_dim: int = None):
        """
        Args:
            n_actions: Number of arms (strategies).
            alpha: Exploration parameter controlling UCB width.
                   Higher α → more exploration. Tuned via validation.
            feature_dim: Dimension of the context feature vector.
                         If None, initialized on first call.
        """
        self.n_actions = n_actions
        self.alpha = alpha
        self.feature_dim = feature_dim
        self._initialized = False

        # Per-arm matrices — initialized lazily when feature_dim is known
        self.A = None  # List of d×d matrices
        self.b = None  # List of d-dim vectors
        self.A_inv = None  # Cached inverses for efficiency

    def _initialize(self, dim: int):
        """Lazily initialize per-arm matrices when feature dimension is known."""
        self.feature_dim = dim
        self.A = [np.eye(dim) for _ in range(self.n_actions)]
        self.b = [np.zeros(dim) for _ in range(self.n_actions)]
        self.A_inv = [np.eye(dim) for _ in range(self.n_actions)]
        self._initialized = True

    def get_name(self) -> str:
        return f"LinUCB(α={self.alpha})"

    def select_action(self, state: np.ndarray) -> int:
        """Select action using LinUCB policy.

        For each arm a:
          θ̂ₐ = Aₐ⁻¹ bₐ
          pₐ = θ̂ₐᵀx + α * sqrt(xᵀ Aₐ⁻¹ x)
        Return argmax(pₐ)
        """
        if not self._initialized:
            self._initialize(len(state))

        x = state.astype(np.float64)
        ucb_values = np.zeros(self.n_actions)

        for a in range(self.n_actions):
            theta_hat = self.A_inv[a] @ self.b[a]             # Ridge regression estimate
            pred = theta_hat @ x                               # Expected reward
            uncertainty = np.sqrt(x @ self.A_inv[a] @ x)      # Confidence width
            ucb_values[a] = pred + self.alpha * uncertainty

        return int(np.argmax(ucb_values))

    def update(self, state: np.ndarray, action: int, reward: float):
        """Update arm's model after observing reward.

        Aₐ ← Aₐ + xxᵀ
        bₐ ← bₐ + r·x
        Aₐ⁻¹ updated via Sherman-Morrison for efficiency.
        """
        if not self._initialized:
            self._initialize(len(state))

        x = state.astype(np.float64)
        a = action

        # Update A and b
        self.A[a] += np.outer(x, x)
        self.b[a] += reward * x

        # Sherman-Morrison inverse update: (A + xxᵀ)⁻¹ = A⁻¹ - (A⁻¹ x xᵀ A⁻¹) / (1 + xᵀ A⁻¹ x)
        A_inv_x = self.A_inv[a] @ x
        denom = 1.0 + x @ A_inv_x
        self.A_inv[a] -= np.outer(A_inv_x, A_inv_x) / denom
