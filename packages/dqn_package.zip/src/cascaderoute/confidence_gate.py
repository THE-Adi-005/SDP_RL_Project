class ConfidenceGate:
    """Implements Chain of Responsibility for reasoning strategies with self-consistency."""
    
    def __init__(self, strategies_dict):
        self.strategies = strategies_dict
        
        # Escalation chains
        self.chains = {
            "3b_direct": "3b_cot",
            "3b_cot": None,  
            "7b_direct": "7b_cot",
            "7b_cot": "7b_got",
            "7b_got": "7b_tot",
            "7b_tot": None   
        }

    def solve_with_cascade(self, initial_action_name: str, question: str):
        current_action = initial_action_name
        escalation_count = 0
        
        while current_action is not None:
            strategy = self.strategies[current_action]
            
            # Run 1 at temp=0.2 (default)
            strategy.llm.temperature = 0.2
            res1 = strategy.solve(question)
            
            # Run 2 at temp=0.8 for self-consistency check
            strategy.llm.temperature = 0.8
            res2 = strategy.solve(question)
            
            # Restore default
            strategy.llm.temperature = 0.2
            
            # Combine metrics
            res1.input_tokens += res2.input_tokens
            res1.output_tokens += res2.output_tokens
            res1.latency += res2.latency
            res1.n_llm_calls += res2.n_llm_calls
            
            # Check consistency
            if res1.predicted_answer == res2.predicted_answer and res1.predicted_answer != "":
                return res1, current_action, escalation_count
                
            # Mismatch -> Escalate
            next_action = self.chains.get(current_action)
            if next_action is None:
                return res1, current_action, escalation_count
                
            current_action = next_action
            escalation_count += 1
            
        return res1, initial_action_name, escalation_count
