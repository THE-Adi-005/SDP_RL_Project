CascadeRoute-VL (CVPR 2027) - Self-Contained LaTeX / Overleaf Bundle
=======================================================================
1. Upload this ZIP in Overleaf: New Project -> Upload Project -> select CascadeRoute_VL_Overleaf.zip.
2. In Overleaf, set Compiler = pdfLaTeX (or XeLaTeX; 100% pure ASCII .tex/.bib compatible with both).
3. Main Paper: set Menu -> Main document = CascadeRoute_VL_CVPR2027.tex (builds 8-page main body + 2-page refs).
4. Supplementary: set Menu -> Main document = Supplementary.tex (builds 5-page supplementary PDF).
5. Before OpenReview upload: replace \def\paperID{****} with your assigned OpenReview Paper ID in both .tex files.
